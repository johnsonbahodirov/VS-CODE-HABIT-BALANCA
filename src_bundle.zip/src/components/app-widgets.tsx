import { useEffect, useMemo, useRef, useState } from "react";
import {
  Play,
  Square,
  Check,
  Trash2,
  Timer as TimerIcon,
  Archive,
  Pencil,
  Pause,
  PlayCircle,
  Minus,
  Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DatabaseErrorNotice } from "@/components/database-error-notice";
import { cn } from "@/lib/utils";
import { dayKey, formatMinutes, minutesByDay, minutesByHabitAndDay } from "@/lib/balance";
import { habitIcon } from "@/lib/habit-meta";
import {
  colorBg,
  useDeleteHabit,
  useDeleteSession,
  useHabitLogs,
  useHabits,
  useSessions,
  useSettings,
  useSaveSettings,
  useTimer,
  useToggleLog,
  useUpdateHabit,
} from "@/lib/data";
import { toast } from "sonner";
import { isHabitScheduledOnDay, scheduledStreakStats } from "@/lib/gamification";
import { HABIT_CATEGORIES } from "@/lib/habit-meta";
import { HABIT_COLORS } from "@/lib/data";
import type { Database } from "@/integrations/supabase/types";

type Habit = Database["public"]["Tables"]["habits"]["Row"];

function useNow(ms = 1000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

export function TimerCard() {
  const { data: sessions = [] } = useSessions();
  const { data: habits = [] } = useHabits();
  const { data: settings } = useSettings();
  const timer = useTimer();
  const saveSettings = useSaveSettings();
  const now = useNow();
  const [habitId, setHabitId] = useState<string>("");
  const [mode, setMode] = useState<"stopwatch" | "pomodoro">("stopwatch");
  const [focusEndsAt, setFocusEndsAt] = useState<number | null>(null);
  const [breakEndsAt, setBreakEndsAt] = useState<number | null>(null);
  const [breakReady, setBreakReady] = useState(false);
  const [nextBreakMinutes, setNextBreakMinutes] = useState(5);
  const completedFocus = useRef(false);
  const [targetCount, setTargetCount] = useState(4);
  const [plan, setPlan] = useState<{ target: number; done: number } | null>(null);

  const running = sessions.find((session) => !session.ended_at);
  const runningId = running?.id;
  const runningMode = running?.mode;
  const selectableHabits = habits.filter((habit) => !habit.is_paused && !habit.archived_at);
  const today = dayKey(now);

  const completedSessions = useMemo(
    () => sessions.filter((session) => session.ended_at),
    [sessions],
  );
  const cycles = completedSessions.filter((session) => session.mode === "pomodoro").length;
  const completedMinutesByDay = useMemo(() => minutesByDay(completedSessions), [completedSessions]);

  const runningTodayMin = running
    ? Math.max(
        0,
        now.getTime() -
          Math.max(
            new Date(running.started_at).getTime(),
            new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime(),
          ),
      ) / 60000
    : 0;
  const todayMin = (completedMinutesByDay.get(today) ?? 0) + runningTodayMin;
  const runningMin = running ? (now.getTime() - new Date(running.started_at).getTime()) / 60000 : 0;
  const runningHabit = habits.find((habit) => habit.id === running?.habit_id);
  const selected = selectableHabits.some((habit) => habit.id === habitId) ? habitId : "";

  const activeFocusEndsAt =
    focusEndsAt ??
    (running?.mode === "pomodoro"
      ? new Date(running.started_at).getTime() + (settings?.pomodoro_focus_minutes ?? 25) * 60000
      : null);

  const focusSeconds = Math.max(
    0,
    Math.ceil(((activeFocusEndsAt ?? now.getTime()) - now.getTime()) / 1000),
  );
  const breakSeconds = Math.max(
    0,
    Math.ceil(((breakEndsAt ?? now.getTime()) - now.getTime()) / 1000),
  );

  const displaySeconds =
    mode === "pomodoro"
      ? running && activeFocusEndsAt
        ? focusSeconds
        : breakEndsAt
          ? breakSeconds
          : breakReady
            ? 0
            : (settings?.pomodoro_focus_minutes ?? 25) * 60
      : Math.floor(runningMin * 60);

  const formattedClock = `${String(Math.floor(displaySeconds / 60)).padStart(2, "0")}:${String(displaySeconds % 60).padStart(2, "0")}`;

  useEffect(() => {
    try {
      const saved = localStorage.getItem("balance-pomodoro");
      if (!saved) return;

      const parsed = JSON.parse(saved) as {
        mode?: "stopwatch" | "pomodoro";
        focusEndsAt?: number | null;
        breakEndsAt?: number | null;
        breakReady?: boolean;
        nextBreakMinutes?: number;
        plan?: { target: number; done: number } | null;
      };

      // Do not restore an expired break timer.
      const validBreakEndsAt =
        parsed.breakEndsAt && parsed.breakEndsAt > Date.now() ? parsed.breakEndsAt : null;

      setPlan(parsed.plan ?? null);
      setMode(parsed.mode === "pomodoro" ? "pomodoro" : "stopwatch");
      setFocusEndsAt(parsed.focusEndsAt ?? null);
      setBreakEndsAt(validBreakEndsAt);
      setBreakReady(parsed.breakReady ?? false);
      setNextBreakMinutes(parsed.nextBreakMinutes ?? 5);
    } catch (error) {
      console.error("Could not restore the timer state.", error);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "balance-pomodoro",
      JSON.stringify({
        mode,
        focusEndsAt,
        breakEndsAt,
        breakReady,
        nextBreakMinutes,
        plan,
      }),
    );
  }, [mode, focusEndsAt, breakEndsAt, breakReady, nextBreakMinutes, plan]);

  useEffect(() => {
    if (!running) completedFocus.current = false;

    if (
      !running ||
      !activeFocusEndsAt ||
      now.getTime() < activeFocusEndsAt ||
      completedFocus.current
    ) {
      return;
    }

    completedFocus.current = true;

    const nextCycle = cycles + 1;
    const breakMinutes =
      nextCycle % 4 === 0
        ? (settings?.pomodoro_long_break_minutes ?? 15)
        : (settings?.pomodoro_short_break_minutes ?? 5);

    timer.mutate(
      { runningId: running.id, endedAt: new Date(activeFocusEndsAt).toISOString() },
      {
        onSuccess: () => {
          setFocusEndsAt(null);

          const finished = plan ? plan.done + 1 >= plan.target : true;
          setPlan((current) =>
            current && current.done + 1 < current.target
              ? { ...current, done: current.done + 1 }
              : null,
          );

          setNextBreakMinutes(breakMinutes);
          setBreakReady(true);

          toast.success(finished && plan ? "Pomodoro plan complete" : "Focus session complete", {
            description: "Take a break or continue when you’re ready.",
          });

          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            new Notification("Focus session complete", {
              body: "Take a break or continue when you’re ready.",
            });
          }
        },
        onError: () => {
          completedFocus.current = false;
        },
      },
    );
  }, [now, running, activeFocusEndsAt, cycles, settings, timer, plan]);

  useEffect(() => {
    if (runningId) {
      setMode(runningMode === "pomodoro" ? "pomodoro" : "stopwatch");
    }
  }, [runningId, runningMode]);

  useEffect(() => {
    if (breakEndsAt && now.getTime() >= breakEndsAt) {
      setBreakEndsAt(null);
      toast.success("Break complete", { description: "Ready for another focus session?" });
    }
  }, [now, breakEndsAt]);

  const startPomodoro = () => {
    if (!selected) {
      toast.error("Choose a habit before starting the timer.");
      return;
    }

    const duration = settings?.pomodoro_focus_minutes ?? 25;
    completedFocus.current = false;
    setBreakReady(false);

    if (!plan) {
      setPlan({ target: targetCount, done: 0 });
    }

    setFocusEndsAt(Date.now() + duration * 60000);
    timer.mutate(
      { runningId: null, habitId: selected, mode: "pomodoro" },
      {
        onError: () => setFocusEndsAt(null),
      },
    );
  };

  const locked =
    Boolean(running) ||
    Boolean(breakEndsAt) ||
    breakReady ||
    (mode === "pomodoro" && Boolean(plan));

  const focusTotal = (settings?.pomodoro_focus_minutes ?? 25) * 60;
  const ringProgress =
    mode === "pomodoro"
      ? running && activeFocusEndsAt
        ? 1 - focusSeconds / focusTotal
        : breakEndsAt
          ? 1 -
            breakSeconds /
              ((cycles % 4 === 0
                ? (settings?.pomodoro_long_break_minutes ?? 15)
                : (settings?.pomodoro_short_break_minutes ?? 5)) *
                60)
          : 0
      : running
        ? (runningMin % 60) / 60
        : 0;

  const R = 92;
  const C = 2 * Math.PI * R;
  const dotsTotal = plan?.target ?? targetCount;
  const dotsDone = plan?.done ?? 0;
  const stepperBtn =
    "flex size-8 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-all hover:bg-primary/20 active:scale-90 disabled:opacity-40";

  return (
    <section className="rounded-3xl border bg-surface p-5">
      <div className="mx-auto mb-5 flex max-w-xs rounded-full bg-cell p-1">
        {(["stopwatch", "pomodoro"] as const).map((timerMode) => (
          <button
            type="button"
            key={timerMode}
            disabled={locked}
            onClick={() => setMode(timerMode)}
            className={cn(
              "flex-1 rounded-full py-2 text-sm font-semibold transition-colors disabled:opacity-50",
              mode === timerMode ? "bg-background text-primary shadow-sm" : "text-muted-foreground",
            )}
          >
            {timerMode === "pomodoro" ? "Pomodoro" : "Stopwatch"}
          </button>
        ))}
      </div>

      <div className="relative mx-auto aspect-square w-full max-w-[240px]">
        <svg viewBox="0 0 220 220" className="size-full -rotate-90">
          <circle cx="110" cy="110" r={R} fill="none" stroke="var(--cell)" strokeWidth="12" />
          <circle
            cx="110"
            cy="110"
            r={R}
            fill="none"
            stroke={breakEndsAt ? "var(--accent)" : "var(--primary)"}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={C}
            strokeDashoffset={C * (1 - Math.max(0, Math.min(1, ringProgress)))}
            className="transition-[stroke-dashoffset] duration-1000"
          />
          {mode === "pomodoro" &&
            Array.from({ length: dotsTotal }, (_, index) => {
              const angle = (index / dotsTotal) * 2 * Math.PI;
              return (
                <circle
                  key={index}
                  cx={110 + 108 * Math.cos(angle)}
                  cy={110 + 108 * Math.sin(angle)}
                  r="4"
                  fill={index < dotsDone ? "var(--primary)" : "var(--border)"}
                />
              );
            })}
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground">
            {mode === "pomodoro"
              ? running
                ? "Focus"
                : breakEndsAt
                  ? "Break"
                  : breakReady
                    ? "Session complete"
                    : "Ready"
              : running
                ? "Tracking"
                : "Today"}
          </p>
          <p className="mt-1 font-mono text-4xl font-bold">
            {mode === "pomodoro" ? formattedClock : formatMinutes(running ? runningMin : todayMin)}
          </p>
          {mode === "pomodoro" && (
            <p className="mt-1 text-xs font-semibold text-primary">
              🍅 {dotsDone}/{dotsTotal}
            </p>
          )}
          {running && (
            <p className="mt-1 max-w-[140px] truncate text-xs text-muted-foreground">
              {runningHabit?.name ?? "General"}
            </p>
          )}
        </div>
      </div>

      {mode === "pomodoro" && !locked && !selected && (
        <div className="mt-4 grid grid-cols-2 gap-2">
          {(
            [
              ["count", "Pomodoros", targetCount, ""],
              ["pomodoro_focus_minutes", "Focus", settings?.pomodoro_focus_minutes ?? 25, "m"],
              [
                "pomodoro_short_break_minutes",
                "Break",
                settings?.pomodoro_short_break_minutes ?? 5,
                "m",
              ],
              [
                "pomodoro_long_break_minutes",
                "Long break",
                settings?.pomodoro_long_break_minutes ?? 15,
                "m",
              ],
            ] as const
          ).map(([key, label, value, unit]) => {
            const change = (delta: number) => {
              if (key === "count") {
                setTargetCount((current) => Math.max(1, Math.min(12, current + delta)));
              } else {
                saveSettings.mutate({ [key]: value + delta });
              }
            };

            return (
              <div
                key={key}
                className="flex items-center justify-between gap-1 rounded-2xl border bg-cell/60 p-1.5"
              >
                <button
                  type="button"
                  aria-label={`Decrease ${label}`}
                  disabled={value <= 1 || saveSettings.isPending}
                  onClick={() => change(-1)}
                  className={stepperBtn}
                >
                  <Minus className="size-4" />
                </button>
                <span className="min-w-0 text-center">
                  <span className="block truncate text-[10px] uppercase tracking-wide text-muted-foreground">
                    {label}
                  </span>
                  <span className="font-mono text-sm font-bold">
                    {value}
                    {unit}
                  </span>
                </span>
                <button
                  type="button"
                  aria-label={`Increase ${label}`}
                  disabled={value >= (key === "count" ? 12 : 180) || saveSettings.isPending}
                  onClick={() => change(1)}
                  className={stepperBtn}
                >
                  <Plus className="size-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {!running && !locked && selectableHabits.length > 0 && (
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
          {selectableHabits.map((habit) => {
            const Icon = habitIcon(habit.icon);
            return (
              <button
                key={habit.id}
                type="button"
                onClick={() => setHabitId(selected === habit.id ? "" : habit.id)}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-full px-3 py-1.5 text-sm transition-all active:scale-95",
                  selected === habit.id
                    ? cn(colorBg[habit.color], "text-background")
                    : "bg-cell text-muted-foreground",
                )}
              >
                <Icon className="size-4" /> {habit.name}
              </button>
            );
          })}
        </div>
      )}

      {mode === "pomodoro" && plan && !running && breakEndsAt && (
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Times are locked until all {plan.target} pomodoros are done.
        </p>
      )}

      {mode === "pomodoro" && breakReady && !running && (
        <div className="mt-4 rounded-2xl bg-cell/60 p-4 text-center">
          <p className="text-sm font-semibold">Focus session complete</p>
          <p className="mt-1 text-xs text-muted-foreground">Choose what you’d like to do next.</p>
          <div className="mt-3 flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => {
                setBreakEndsAt(Date.now() + nextBreakMinutes * 60000);
                setBreakReady(false);
              }}
            >
              Take a {nextBreakMinutes}-minute break
            </Button>
            <Button
              type="button"
              className="flex-1"
              disabled={timer.isPending}
              onClick={startPomodoro}
            >
              Continue focusing
            </Button>
          </div>
        </div>
      )}

      <Button
        variant={running ? "amber" : "neon"}
        size="lg"
        className="mt-5 w-full"
        disabled={
          timer.isPending ||
          (!running && !breakEndsAt && !breakReady && !selected && !plan)
        }
        onClick={() => {
          if (mode === "pomodoro") {
            if (running) {
              timer.mutate(
                { runningId: running.id },
                { onSuccess: () => setFocusEndsAt(null) },
              );
            } else if (breakEndsAt) {
              setBreakEndsAt(null);
            } else if (!breakReady) {
              if (!selected && plan) {
                const lastHabit = sessions.find((session) => session.mode === "pomodoro")?.habit_id;
                if (lastHabit) setHabitId(lastHabit);
              }
              startPomodoro();
            }
          } else {
            if (!running && !selected) {
              toast.error("Choose a habit before starting the timer.");
              return;
            }
            timer.mutate({
              runningId: running?.id ?? null,
              habitId: selected,
              mode: "stopwatch",
            });
          }
        }}
      >
        {running ? <Square /> : <Play />}
        {mode === "pomodoro"
          ? running
            ? "End focus"
            : breakEndsAt
              ? "Skip break"
              : breakReady
                ? "Choose next step above"
                : plan
                  ? `Start pomodoro ${plan.done + 1}/${plan.target}`
                  : "Start focus"
          : running
            ? "Stop"
            : "Start timer"}
      </Button>

      {!running && !breakEndsAt && !breakReady && !selected && (
        <p className="mt-2 text-center text-xs text-muted-foreground">
          {mode === "pomodoro" && !plan
            ? "Set your times, then pick a habit to start."
            : "Select a habit above to start tracking time."}
        </p>
      )}
    </section>
  );
}
export function SessionList() {
  const { data: sessions = [] } = useSessions();
  const { data: habits = [] } = useHabits();
  const del = useDeleteSession();
  const now = useNow(30000);
  if (!sessions.length) return <p className="text-sm text-muted-foreground">No sessions yet.</p>;
  return (
    <ul className="space-y-2">
      {sessions.slice(0, 30).map((s) => {
        const start = new Date(s.started_at);
        const end = s.ended_at ? new Date(s.ended_at) : now;
        const mins = (end.getTime() - start.getTime()) / 60000;
        const t = (d: Date) => d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        return (
          <li
            key={s.id}
            className="flex items-center justify-between rounded-2xl bg-surface px-4 py-3"
          >
            <div>
              <p className="text-sm font-semibold">
                {habits.find((h) => h.id === s.habit_id)?.name ?? "General"}
              </p>
              <p className="text-xs text-muted-foreground">
                {start.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}
                {" · "}
                {s.mode === "pomodoro" ? "Pomodoro" : "Stopwatch"}
              </p>
              <p className="font-mono text-xs text-muted-foreground">
                {t(start)} – {s.ended_at ? t(end) : "now"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm">{formatMinutes(mins)}</span>
              <button
                aria-label="Delete session"
                onClick={() => del.mutate(s.id)}
                className="p-1 text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="size-4" />
              </button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function lastDays(n: number): string[] {
  const out: string[] = [];
  const d = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const x = new Date(d);
    x.setDate(d.getDate() - i);
    out.push(dayKey(x));
  }
  return out;
}

export function HabitList({ showGrid = true }: { showGrid?: boolean }) {
  const now = useNow(30000);
  const {
    data: habits = [],
    error: habitsError,
    isError: hasHabitsError,
    isLoading,
    refetch: refetchHabits,
  } = useHabits();
  const {
    data: logs = [],
    error: logsError,
    isError: hasLogsError,
    refetch: refetchLogs,
  } = useHabitLogs();
  const {
    data: sessions = [],
    error: sessionsError,
    isError: hasSessionsError,
    refetch: refetchSessions,
  } = useSessions();
  const toggle = useToggleLog();
  const del = useDeleteHabit();
  const updateHabit = useUpdateHabit();
  const [showArchived, setShowArchived] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const today = dayKey(now);
  const days = lastDays(119);
  const weekDays = lastDays(7);
  const logsByHabitDay = useMemo(
    () => new Map(logs.map((log) => [`${log.habit_id}|${log.day}`, log.count])),
    [logs],
  );
  const done = useMemo(
    () =>
      new Set(
        logs
          .filter((log) => {
            const habit = habits.find((item) => item.id === log.habit_id);
            return habit?.tracking_type !== "count" || log.count >= (habit.daily_goal_count ?? 1);
          })
          .map((log) => `${log.habit_id}|${log.day}`),
      ),
    [logs, habits],
  );
  const daysByHabit = useMemo(() => {
    const grouped = new Map<string, string[]>();
    for (const log of logs) {
      const habit = habits.find((item) => item.id === log.habit_id);
      if (habit?.tracking_type === "count" && log.count < (habit.daily_goal_count ?? 1)) continue;
      const habitDays = grouped.get(log.habit_id) ?? [];
      habitDays.push(log.day);
      grouped.set(log.habit_id, habitDays);
    }
    return grouped;
  }, [logs, habits]);
  const timeByHabit = useMemo(() => minutesByHabitAndDay(sessions, now), [sessions, now]);
  const visibleHabits = habits.filter((habit) => !habit.archived_at || showArchived);

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (hasHabitsError)
    return (
      <DatabaseErrorNotice
        title="Habits could not be loaded"
        error={habitsError}
        onRetry={() => {
          void refetchHabits();
        }}
      />
    );
  if (hasLogsError || hasSessionsError)
    return (
      <DatabaseErrorNotice
        title="Habit history or focus sessions could not be loaded"
        error={logsError ?? sessionsError}
        onRetry={() => {
          void Promise.all([refetchLogs(), refetchSessions()]);
        }}
      />
    );
  if (!habits.length)
    return (
      <p className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">
        No habits yet — add your first one.
      </p>
    );

  if (!visibleHabits.length)
    return (
      <div className="space-y-3">
        <p className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">
          {showArchived
            ? "No habits to show."
            : "No active habits. Add one or view archived habits."}
        </p>
        {showGrid && (
          <button
            type="button"
            onClick={() => setShowArchived((value) => !value)}
            className="w-full text-center text-sm text-primary"
          >
            {showArchived ? "Hide archived habits" : "Show archived habits"}
          </button>
        )}
      </div>
    );

  return (
    <>
      {showGrid && (
        <button
          type="button"
          onClick={() => setShowArchived((value) => !value)}
          className="mb-3 text-sm text-primary"
        >
          {showArchived ? "Hide archived habits" : "Show archived habits"}
        </button>
      )}
      <ul className="space-y-3">
        {visibleHabits.map((h) => {
          const isArchived = Boolean(h.archived_at);
          const inactive = isArchived || h.is_paused || !isHabitScheduledOnDay(h, today);
          const isDone = done.has(`${h.id}|${today}`);
          const minutes = timeByHabit.get(`${h.id}|${today}`) ?? 0;
          const goal = h.daily_goal_minutes ?? 30;
          const streak = scheduledStreakStats(daysByHabit.get(h.id) ?? [], today, h);
          const scheduledThisWeek = weekDays.filter((day) => isHabitScheduledOnDay(h, day)).length;
          const completedThisWeek = weekDays.filter((day) => done.has(`${h.id}|${day}`)).length;
          return (
            <li
              key={h.id}
              className="rounded-2xl border border-rose-950/10 bg-surface px-3 py-3 dark:border-rose-200/10"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <HabitBadge
                    icon={h.icon}
                    color={h.color}
                    className="size-9 rounded-xl [&>svg]:size-4"
                  />
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{h.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {h.category} ·{" "}
                      {isArchived
                        ? "Archived"
                        : h.is_paused
                          ? "Paused"
                          : `${streak.current} day streak`}
                    </p>
                    {!isArchived && (
                      <p className="text-[11px] text-muted-foreground">
                        This week · {completedThisWeek}/{scheduledThisWeek} days
                      </p>
                    )}
                    {h.description && (
                      <p className="mt-0.5 truncate text-xs text-muted-foreground">
                        {h.description}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {showGrid && (
                    <>
                      <button
                        type="button"
                        aria-label={`Edit ${h.name}`}
                        onClick={() => setEditingHabit(h)}
                        className="p-2 text-muted-foreground hover:text-foreground"
                      >
                        <Pencil className="size-4" />
                      </button>
                      {!isArchived && (
                        <button
                          type="button"
                          aria-label={h.is_paused ? `Resume ${h.name}` : `Pause ${h.name}`}
                          onClick={() =>
                            updateHabit.mutate({ id: h.id, updates: { is_paused: !h.is_paused } })
                          }
                          className="p-2 text-muted-foreground hover:text-foreground"
                        >
                          {h.is_paused ? (
                            <PlayCircle className="size-4" />
                          ) : (
                            <Pause className="size-4" />
                          )}
                        </button>
                      )}
                      <button
                        type="button"
                        aria-label={isArchived ? `Restore ${h.name}` : `Archive ${h.name}`}
                        onClick={() => {
                          if (isArchived) {
                            updateHabit.mutate({ id: h.id, updates: { archived_at: null } });
                          } else if (confirm("Archive this habit? Its history will be kept.")) {
                            del.mutate(h.id);
                          }
                        }}
                        className="p-2 text-muted-foreground hover:text-destructive"
                      >
                        <Archive className="size-4" />
                      </button>
                    </>
                  )}
                  {h.tracking_type === "count" ? (
                    <div className="flex items-center gap-1.5 rounded-xl bg-cell/70 p-1">
                      <button
                        type="button"
                        aria-label={`Decrease ${h.name} count`}
                        disabled={
                          toggle.isPending ||
                          inactive ||
                          (logsByHabitDay.get(`${h.id}|${today}`) ?? 0) <= 0
                        }
                        onClick={() =>
                          toggle.mutate({
                            habit_id: h.id,
                            day: today,
                            done: false,
                            count: (logsByHabitDay.get(`${h.id}|${today}`) ?? 0) - 1,
                          })
                        }
                        className="flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-background disabled:opacity-40"
                      >
                        −
                      </button>
                      <span
                        aria-label={`${logsByHabitDay.get(`${h.id}|${today}`) ?? 0} of ${h.daily_goal_count} completed`}
                        className={cn(
                          "min-w-10 text-center font-mono text-sm font-semibold",
                          isDone && "text-rose-400",
                        )}
                      >
                        {logsByHabitDay.get(`${h.id}|${today}`) ?? 0}/{h.daily_goal_count}
                      </span>
                      <button
                        type="button"
                        aria-label={`Increase ${h.name} count`}
                        disabled={
                          toggle.isPending ||
                          inactive ||
                          (logsByHabitDay.get(`${h.id}|${today}`) ?? 0) >= 999
                        }
                        onClick={() =>
                          toggle.mutate({
                            habit_id: h.id,
                            day: today,
                            done: false,
                            count: (logsByHabitDay.get(`${h.id}|${today}`) ?? 0) + 1,
                          })
                        }
                        className="flex size-8 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/25"
                      >
                        +
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      aria-label={isDone ? "Mark not done" : "Mark done"}
                      disabled={toggle.isPending || inactive}
                      onClick={() => {
                        if (!isDone && typeof navigator !== "undefined") navigator.vibrate?.(15);
                        toggle.mutate({ habit_id: h.id, day: today, done: isDone });
                      }}
                      className={cn(
                        "flex size-9 items-center justify-center rounded-xl transition-all",
                        isDone
                          ? cn(colorBg[h.color], "habit-pop text-background")
                          : "bg-cell text-muted-foreground",
                      )}
                    >
                      <Check className="size-4" />
                    </button>
                  )}
                </div>
              </div>
              {h.tracking_type !== "count" && !isArchived && (
                <div className="mt-2">
                  <div className="mb-1.5 flex justify-between text-xs text-muted-foreground">
                    <span>Today's focus</span>
                    <span>
                      {formatMinutes(minutes)} / {goal}m
                    </span>
                  </div>
                  <div
                    role="progressbar"
                    aria-label={`${h.name} time goal`}
                    aria-valuenow={Math.min(100, Math.round((minutes / goal) * 100))}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    className="h-2 overflow-hidden rounded-full bg-cell"
                  >
                    <div
                      className={cn("h-full rounded-full transition-all", colorBg[h.color])}
                      style={{ width: `${Math.min(100, (minutes / goal) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
              {showGrid && (
                <div className="mt-3 flex flex-wrap gap-[3px]">
                  {days.slice(-56).map((d) => (
                    <span
                      key={d}
                      title={d}
                      aria-label={`${h.name} ${d}${done.has(`${h.id}|${d}`) ? " completed" : ""}`}
                      className={cn(
                        "size-2.5 rounded-[2px]",
                        done.has(`${h.id}|${d}`) ? colorBg[h.color] : "bg-cell/70",
                      )}
                    />
                  ))}
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <HabitEditDialog habit={editingHabit} onClose={() => setEditingHabit(null)} />
    </>
  );
}

function HabitEditDialog({ habit, onClose }: { habit: Habit | null; onClose: () => void }) {
  const update = useUpdateHabit();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("Health");
  const [color, setColor] = useState<string>("rose");
  const [frequency, setFrequency] = useState<Habit["frequency"]>("daily");
  const [scheduleDays, setScheduleDays] = useState<number[]>([]);
  const [difficulty, setDifficulty] = useState<Habit["difficulty"]>("medium");
  const [trackingType, setTrackingType] = useState<Habit["tracking_type"]>("yes_no");
  const [dailyGoalCount, setDailyGoalCount] = useState(1);
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState(30);
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState("09:00");

  useEffect(() => {
    if (!habit) return;
    setName(habit.name);
    setDescription(habit.description);
    setCategory(habit.category);
    setColor(habit.color);
    setFrequency(habit.frequency);
    setScheduleDays(habit.schedule_days);
    setDifficulty(habit.difficulty);
    setTrackingType(habit.tracking_type);
    setDailyGoalCount(habit.daily_goal_count);
    setDailyGoalMinutes(habit.daily_goal_minutes);
    setReminderEnabled(habit.reminder_enabled);
    setReminderTime(habit.reminder_time);
  }, [habit]);

  const weekdayControls = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return (
    <Dialog open={Boolean(habit)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:rounded-3xl">
        <DialogHeader>
          <DialogTitle>Edit habit</DialogTitle>
        </DialogHeader>
        {habit && (
          <form
            className="space-y-4"
            onSubmit={(event) => {
              event.preventDefault();
              if (!name.trim()) return;
              const validScheduleDays =
                scheduleDays.length > 0 ? scheduleDays : [0, 1, 2, 3, 4, 5, 6];
              update.mutate(
                {
                  id: habit.id,
                  updates: {
                    name: name.trim(),
                    description,
                    category,
                    color,
                    frequency,
                    schedule_days: validScheduleDays,
                    difficulty,
                    tracking_type: trackingType,
                    daily_goal_count: dailyGoalCount,
                    daily_goal_minutes: dailyGoalMinutes,
                    reminder_enabled: reminderEnabled,
                    reminder_time: reminderTime,
                  },
                },
                { onSuccess: onClose },
              );
            }}
          >
            <Input value={name} onChange={(event) => setName(event.target.value)} maxLength={120} />
            <Textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Purpose or note"
              maxLength={1000}
            />
            <div className="grid grid-cols-2 gap-2">
              <label className="text-xs text-muted-foreground">
                Category
                <select
                  value={category}
                  onChange={(event) => setCategory(event.target.value)}
                  className="mt-1 h-10 w-full rounded-xl border bg-cell px-3 text-sm text-foreground"
                >
                  {HABIT_CATEGORIES.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </label>
              <label className="text-xs text-muted-foreground">
                Difficulty
                <select
                  value={difficulty}
                  onChange={(event) => setDifficulty(event.target.value)}
                  className="mt-1 h-10 w-full rounded-xl border bg-cell px-3 text-sm text-foreground"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </label>
            </div>
            <label className="block text-xs text-muted-foreground">
              Frequency
              <select
                value={
                  frequency === "selected_days" &&
                  scheduleDays.length === 2 &&
                  scheduleDays.includes(0) &&
                  scheduleDays.includes(6)
                    ? "weekends"
                    : frequency
                }
                onChange={(event) => {
                  const next = event.target.value;
                  if (next === "weekends") {
                    setFrequency("selected_days");
                    setScheduleDays([0, 6]);
                  } else {
                    setFrequency(next as Habit["frequency"]);
                    if (next === "daily") setScheduleDays([0, 1, 2, 3, 4, 5, 6]);
                    if (next === "weekdays") setScheduleDays([1, 2, 3, 4, 5]);
                    if (next === "selected_days" && scheduleDays.length === 0)
                      setScheduleDays([1, 2, 3, 4, 5]);
                    if (next === "custom" && scheduleDays.length === 0)
                      setScheduleDays([0, 1, 2, 3, 4, 5, 6]);
                  }
                }}
                className="mt-1 h-10 w-full rounded-xl border bg-cell px-3 text-sm text-foreground"
              >
                <option value="daily">Every day</option>
                <option value="weekdays">Weekdays (Mon-Fri)</option>
                <option value="weekends">Weekends (Sat-Sun)</option>
                <option value="selected_days">Selected days</option>
                <option value="custom">Custom weekly schedule</option>
              </select>
            </label>
            {(frequency === "selected_days" || frequency === "custom") && (
              <div className="flex flex-wrap gap-2">
                {weekdayControls.map((day, index) => (
                  <button
                    type="button"
                    key={day}
                    aria-pressed={scheduleDays.includes(index)}
                    onClick={() =>
                      setScheduleDays((current) =>
                        current.includes(index)
                          ? current.filter((value) => value !== index)
                          : [...current, index].sort(),
                      )
                    }
                    className={cn(
                      "rounded-full px-3 py-1.5 text-xs font-medium",
                      scheduleDays.includes(index)
                        ? "bg-primary text-primary-foreground"
                        : "bg-cell text-muted-foreground",
                    )}
                  >
                    {day}
                  </button>
                ))}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <label className="text-xs text-muted-foreground">
                Tracking
                <select
                  value={trackingType}
                  onChange={(event) => setTrackingType(event.target.value)}
                  className="mt-1 h-10 w-full rounded-xl border bg-cell px-3 text-sm text-foreground"
                >
                  <option value="yes_no">Yes / No</option>
                  <option value="count">Count</option>
                </select>
              </label>
              {trackingType === "count" ? (
                <label className="text-xs text-muted-foreground">
                  Daily count goal
                  <Input
                    type="number"
                    min={1}
                    max={999}
                    value={dailyGoalCount}
                    onChange={(event) =>
                      setDailyGoalCount(Math.max(1, Math.min(999, Number(event.target.value) || 1)))
                    }
                  />
                </label>
              ) : (
                <label className="text-xs text-muted-foreground">
                  Focus goal (minutes)
                  <Input
                    type="number"
                    min={1}
                    max={1440}
                    value={dailyGoalMinutes}
                    onChange={(event) =>
                      setDailyGoalMinutes(
                        Math.max(1, Math.min(1440, Number(event.target.value) || 1)),
                      )
                    }
                  />
                </label>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {HABIT_COLORS.map((item) => (
                <button
                  type="button"
                  key={item}
                  aria-label={`Choose ${item} color`}
                  aria-pressed={color === item}
                  onClick={() => setColor(item)}
                  className={cn(
                    "size-7 rounded-lg",
                    colorBg[item],
                    color === item && "ring-2 ring-foreground ring-offset-2 ring-offset-surface",
                  )}
                />
              ))}
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(event) => setReminderEnabled(event.target.checked)}
                />
                Reminder
              </label>
              {reminderEnabled && (
                <Input
                  type="time"
                  aria-label="Habit reminder time"
                  value={reminderTime}
                  onChange={(event) => setReminderTime(event.target.value)}
                  className="w-32"
                />
              )}
            </div>
            <Button type="submit" className="w-full" disabled={update.isPending}>
              Save habit
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function HabitBadge({
  icon,
  color,
  className,
}: {
  icon?: string | null;
  color: string;
  className?: string;
}) {
  const Icon = habitIcon(icon);
  return (
    <span
      className={cn(
        "flex size-10 shrink-0 items-center justify-center rounded-2xl text-background",
        colorBg[color],
        className,
      )}
    >
      <Icon className="size-5" />
    </span>
  );
}
