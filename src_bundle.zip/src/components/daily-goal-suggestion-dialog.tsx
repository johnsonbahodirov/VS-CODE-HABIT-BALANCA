import { useEffect, useState } from "react";
import { Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { dayKey, minutesByDay } from "@/lib/balance";
import { wasBelowDailyGoalForThreeDays } from "@/lib/daily-goal";
import { useSaveTarget, useSessions, useSettings } from "@/lib/data";

export function DailyGoalSuggestionDialog() {
  const sessions = useSessions();
  const settings = useSettings();
  const saveGoal = useSaveTarget();
  const [dismissed, setDismissed] = useState(false);
  const now = new Date();
  const dailyGoal = settings.data?.daily_goal_minutes ?? 120;
  const isReady = sessions.isSuccess && settings.isSuccess;
  const minutesByLocalDay = minutesByDay(sessions.data ?? [], now);
  const belowGoalThreeDays =
    isReady && wasBelowDailyGoalForThreeDays(minutesByLocalDay, dailyGoal, now);
  const reducedGoal = Math.max(15, Math.round(dailyGoal * 0.85));
  const isOpen = belowGoalThreeDays && dailyGoal > 15 && !dismissed;

  useEffect(() => {
    if (!belowGoalThreeDays) setDismissed(false);
  }, [belowGoalThreeDays]);

  const saveReducedGoal = () => {
    saveGoal.mutate(reducedGoal, {
      onSuccess: () => setDismissed(true),
    });
  };

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => {
        if (!open) setDismissed(true);
      }}
    >
      <DialogContent className="border-accent/70 bg-surface sm:rounded-3xl">
        <DialogHeader className="items-center text-center">
          <span className="mb-2 flex size-14 items-center justify-center rounded-full bg-accent/20 text-accent">
            <Target className="size-7" />
          </span>
          <DialogTitle className="text-xl">Let’s make your daily plan easier</DialogTitle>
          <DialogDescription>
            You were below your {dailyGoal}-minute plan for the last three days. Would a smaller
            goal help you get back into your routine?
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col-reverse gap-2 sm:flex-col sm:space-x-0">
          <Button onClick={saveReducedGoal} disabled={saveGoal.isPending} className="w-full">
            Reduce goal to {reducedGoal} min
          </Button>
          <Button
            variant="outline"
            disabled={saveGoal.isPending}
            onClick={() => setDismissed(true)}
            className="w-full"
          >
            Keep my current goal
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
