import { useEffect, useMemo, useRef, useState } from "react";
import { Award, Check, Lock, Sparkles, Trophy, Zap } from "lucide-react";
import {
  useAchievements,
  useHabitLogs,
  useHabits,
  useSetAchievementFeatured,
  useXPSummary,
} from "@/lib/data";
import {
  ACHIEVEMENT_CATEGORIES,
  type AchievementCategory,
  type AchievementDefinition,
  detectComeback,
  getAchievementProgress,
  levelForXp,
  scheduledStreakStats,
} from "@/lib/gamification";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { DatabaseErrorNotice } from "@/components/database-error-notice";

export function XpProgressCard({ compact = false }: { compact?: boolean }) {
  const { data, error, isError, isLoading, refetch } = useXPSummary();
  const level = levelForXp(data?.totalXp ?? 0);

  if (isError)
    return (
      <DatabaseErrorNotice
        title="XP data could not be loaded"
        error={error}
        onRetry={() => {
          void refetch();
        }}
      />
    );
  if (isLoading) return <div className="h-28 animate-pulse rounded-3xl bg-cell" />;

  return (
    <section className="rounded-3xl border bg-surface p-4">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-2xl bg-primary/15 text-primary">
            <Award className="size-6" />
          </span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Level {level.level} · {level.title}
            </p>
            <p className="font-mono text-xl font-bold">
              {(data?.totalXp ?? 0).toLocaleString()}{" "}
              <span className="text-sm font-medium text-muted-foreground">XP</span>
            </p>
          </div>
        </div>
        <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          {level.remainingXp.toLocaleString()} to next
        </span>
      </div>
      <div className="mt-4">
        <div className="mb-1.5 flex justify-between text-xs text-muted-foreground">
          <span>{level.progressXp.toLocaleString()} XP</span>
          <span>{level.nextLevelXp.toLocaleString()} XP</span>
        </div>
        <Progress value={level.progress} className="h-2.5" />
      </div>
      {!compact && (
        <p className="mt-3 text-xs text-muted-foreground">
          Keep your routine going—each habit completion earns XP, with extra rewards for streaks.
        </p>
      )}
    </section>
  );
}

export function GamificationFeedback() {
  const xp = useXPSummary();
  const achievements = useAchievements();
  const previousXp = useRef<number | null>(null);
  const previousUnlocked = useRef<Set<string> | null>(null);
  const [levelUp, setLevelUp] = useState<{ level: number; title: string } | null>(null);

  useEffect(() => {
    if (!xp.data) return;
    const level = levelForXp(xp.data.totalXp);
    if (previousXp.current !== null && xp.data.totalXp > previousXp.current) {
      toast.success(`+${xp.data.totalXp - previousXp.current} XP`, { className: "xp-toast" });
      if (level.level > levelForXp(previousXp.current).level) {
        setLevelUp(level);
      }
    }
    previousXp.current = xp.data.totalXp;
  }, [xp.data]);

  useEffect(() => {
    if (!achievements.data) return;
    const unlocked = new Set(achievements.data.unlocked.map((item) => item.achievement_key));
    if (previousUnlocked.current) {
      const newUnlock = achievements.data.catalog.find(
        (item) => unlocked.has(item.key) && !previousUnlocked.current?.has(item.key),
      );
      if (newUnlock) {
        toast.success(`${newUnlock.name} unlocked!`, {
          description: `${newUnlock.description} +${newUnlock.reward_xp} XP`,
          duration: 6000,
          className: "achievement-toast",
        });
      }
    }
    previousUnlocked.current = unlocked;
  }, [achievements.data]);

  return (
    <Dialog
      open={Boolean(levelUp)}
      onOpenChange={(open) => {
        if (!open) setLevelUp(null);
      }}
    >
      <DialogContent className="level-up-dialog border-accent/70 bg-surface sm:rounded-3xl">
        <DialogHeader className="items-center text-center">
          <span className="level-up-emblem mb-2 flex size-16 items-center justify-center rounded-full bg-accent/20 text-accent">
            <Trophy className="size-8" />
          </span>
          <DialogTitle className="text-2xl">Level up!</DialogTitle>
          <DialogDescription>
            You reached level {levelUp?.level} — {levelUp?.title}. Your consistency is paying off.
          </DialogDescription>
        </DialogHeader>
        <div className="mx-auto rounded-full bg-primary/10 px-4 py-2 text-sm font-semibold text-primary">
          Your next milestone is waiting
        </div>
        <Button onClick={() => setLevelUp(null)} className="w-full">
          Keep going
        </Button>
      </DialogContent>
    </Dialog>
  );
}

export function AchievementGrid({
  showLocked = true,
  categoryFilter = "all",
  statusFilter = "all",
}: {
  showLocked?: boolean;
  categoryFilter?: "all" | AchievementCategory;
  statusFilter?: "all" | "unlocked" | "locked";
}) {
  const { data, error, isError, isLoading, refetch } = useAchievements();
  const habitsQuery = useHabits();
  const logsQuery = useHabitLogs();
  const xpQuery = useXPSummary();
  const setFeatured = useSetAchievementFeatured();

  const [activeCategory, setActiveCategory] = useState<"all" | AchievementCategory>(categoryFilter);
  const [activeStatus, setActiveStatus] = useState<"all" | "unlocked" | "locked">(statusFilter);

  useEffect(() => {
    if (categoryFilter !== "all") setActiveCategory(categoryFilter);
  }, [categoryFilter]);

  useEffect(() => {
    if (statusFilter !== "all") setActiveStatus(statusFilter);
  }, [statusFilter]);

  const unlockedMap = useMemo(
    () =>
      new Map(
        (data?.unlocked ?? []).map((item) => [
          item.achievement_key,
          { unlockedAt: item.unlocked_at, featured: item.is_featured },
        ]),
      ),
    [data?.unlocked],
  );

  const userStats = useMemo(() => {
    const habits = habitsQuery.data ?? [];
    const logs = logsQuery.data ?? [];
    const totalXp = xpQuery.data?.totalXp ?? 0;
    const today = new Date().toISOString().slice(0, 10);

    const completedLogs = logs.filter((log) => {
      const h = habits.find((item) => item.id === log.habit_id);
      if (!h) return (log.count ?? 1) >= 1;
      return h.tracking_type === "count"
        ? (log.count ?? 0) >= h.daily_goal_count
        : (log.count ?? 1) >= 1;
    });

    const completedDays = completedLogs.map((l) => l.day);
    const uniqueDays = new Set(completedDays);

    let longestStreak = 0;
    let longestLearningStreak = 0;

    for (const habit of habits) {
      const habitDays = completedLogs.filter((l) => l.habit_id === habit.id).map((l) => l.day);
      const stats = scheduledStreakStats(habitDays, today, habit);
      if (stats.longest > longestStreak) longestStreak = stats.longest;

      const isLearning =
        habit.category.toLowerCase().includes("learn") ||
        habit.name.toLowerCase().includes("learn") ||
        habit.name.toLowerCase().includes("study");
      if (isLearning && stats.longest > longestLearningStreak) {
        longestLearningStreak = stats.longest;
      }
    }

    const readingCompletions = completedLogs.filter((log) => {
      const h = habits.find((item) => item.id === log.habit_id);
      const cat = (h?.category ?? "").toLowerCase();
      const name = (h?.name ?? "").toLowerCase();
      return cat.includes("read") || name.includes("read") || name.includes("book");
    }).length;

    const learningCompletions = completedLogs.filter((log) => {
      const h = habits.find((item) => item.id === log.habit_id);
      const cat = (h?.category ?? "").toLowerCase();
      const name = (h?.name ?? "").toLowerCase();
      return cat.includes("learn") || name.includes("learn") || name.includes("study");
    }).length;

    const workoutCompletions = completedLogs.filter((log) => {
      const h = habits.find((item) => item.id === log.habit_id);
      const cat = (h?.category ?? "").toLowerCase();
      const name = (h?.name ?? "").toLowerCase();
      return (
        cat.includes("fitness") ||
        cat.includes("workout") ||
        name.includes("workout") ||
        name.includes("gym") ||
        name.includes("run") ||
        name.includes("fitness")
      );
    }).length;

    const morningCompletions = completedLogs.filter((log) => {
      const h = habits.find((item) => item.id === log.habit_id);
      const name = (h?.name ?? "").toLowerCase();
      const desc = (h?.description ?? "").toLowerCase();
      return name.includes("morning") || desc.includes("morning");
    }).length;

    const comebackInfo = detectComeback(completedDays, today);
    const levelInfo = levelForXp(totalXp);

    return {
      habitsCount: habits.length,
      totalCompletions: completedLogs.length,
      morningCompletions,
      readingCompletions,
      learningCompletions,
      workoutCompletions,
      longestStreak,
      longestLearningStreak,
      perfectDaysCount: Math.min(
        uniqueDays.size,
        Math.floor(completedLogs.length / Math.max(1, habits.length)),
      ),
      activeUniqueDays: uniqueDays.size,
      totalXp,
      level: levelInfo.level,
      comebackCount: comebackInfo.comebackCycles,
      postComebackLongestStreak: comebackInfo.comebackCycles > 0 ? longestStreak : 0,
      postComebackActiveDays: comebackInfo.comebackCycles > 0 ? uniqueDays.size : 0,
      thirtyDayCompletionRate: Math.min(
        100,
        Math.round((completedLogs.length / Math.max(1, habits.length * 30)) * 100),
      ),
    };
  }, [habitsQuery.data, logsQuery.data, xpQuery.data?.totalXp]);

  if (isError)
    return (
      <DatabaseErrorNotice
        title="Achievements could not be loaded"
        error={error}
        onRetry={() => {
          void refetch();
        }}
      />
    );

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading achievements…</p>;

  const catalog = data?.catalog ?? [];

  const filteredItems = catalog.filter((item) => {
    if (!showLocked && !unlockedMap.has(item.key)) return false;

    if (activeCategory !== "all" && item.category !== activeCategory) {
      return false;
    }

    const isUnlocked = unlockedMap.has(item.key);
    if (activeStatus === "unlocked" && !isUnlocked) return false;
    if (activeStatus === "locked" && isUnlocked) return false;

    return true;
  });

  return (
    <div className="space-y-4">
      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <button
          type="button"
          onClick={() => setActiveCategory("all")}
          className={`rounded-full px-3 py-1.5 font-medium transition-colors ${
            activeCategory === "all"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "bg-surface border text-muted-foreground hover:bg-cell"
          }`}
        >
          All Categories
        </button>
        {ACHIEVEMENT_CATEGORIES.map((cat) => {
          const count = catalog.filter((item) => item.category === cat.id).length;
          const unlockedCount = catalog.filter(
            (item) => item.category === cat.id && unlockedMap.has(item.key),
          ).length;
          const isSelected = activeCategory === cat.id;

          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 font-medium transition-colors ${
                isSelected
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-surface border text-muted-foreground hover:bg-cell"
              }`}
            >
              <span>{cat.name}</span>
              <span
                className={`rounded-full px-1.5 py-0.2 text-[10px] ${
                  isSelected
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : "bg-cell text-muted-foreground"
                }`}
              >
                {unlockedCount}/{count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-1 rounded-2xl border bg-surface/80 p-1 text-xs">
        {(["all", "unlocked", "locked"] as const).map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setActiveStatus(status)}
            className={`flex-1 rounded-xl py-1.5 font-medium capitalize transition-colors ${
              activeStatus === status
                ? "bg-cell text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {status === "all"
              ? `All (${catalog.length})`
              : status === "unlocked"
                ? `Unlocked (${unlockedMap.size})`
                : `Locked (${Math.max(0, catalog.length - unlockedMap.size)})`}
          </button>
        ))}
      </div>

      {/* Achievement Cards Grid */}
      {filteredItems.length === 0 ? (
        <div className="rounded-3xl border bg-surface/50 p-8 text-center">
          <p className="text-sm font-medium text-muted-foreground">
            No achievements found in this section.
          </p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {filteredItems.map((achievement) => {
            const unlock = unlockedMap.get(achievement.key);
            const isUnlocked = Boolean(unlock);
            const unlockedAt = unlock?.unlockedAt;

            const progress = getAchievementProgress(
              achievement as unknown as AchievementDefinition,
              userStats,
              isUnlocked,
            );

            const tierBadgeStyle: Record<string, string> = {
              common: "bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/20",
              rare: "bg-sky-500/15 text-sky-600 dark:text-sky-400 border-sky-500/30",
              epic: "bg-violet-500/15 text-violet-600 dark:text-violet-400 border-violet-500/30",
              legendary:
                "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/40 shadow-sm",
            };

            const tierCardBorder: Record<string, string> = {
              common: isUnlocked ? "border-primary/20" : "border-border/60",
              rare: isUnlocked ? "border-sky-500/30 ring-1 ring-sky-500/20" : "border-border/60",
              epic: isUnlocked
                ? "border-violet-500/30 ring-1 ring-violet-500/20"
                : "border-border/60",
              legendary: isUnlocked
                ? "border-amber-500/40 ring-1 ring-amber-500/30 shadow-md shadow-amber-500/5"
                : "border-border/60",
            };

            return (
              <article
                key={achievement.key}
                className={`relative flex flex-col justify-between rounded-3xl border p-4 transition-all ${
                  isUnlocked ? "bg-surface shadow-sm" : "bg-surface/50 opacity-90 hover:opacity-100"
                } ${tierCardBorder[achievement.tier] ?? "border-border"}`}
              >
                <div>
                  <div className="flex items-start gap-3">
                    <span
                      className={`flex size-12 shrink-0 items-center justify-center rounded-2xl transition-transform ${
                        isUnlocked
                          ? achievement.tier === "legendary"
                            ? "bg-gradient-to-br from-amber-500/30 to-amber-600/10 text-amber-500 shadow-inner"
                            : achievement.tier === "epic"
                              ? "bg-violet-500/20 text-violet-500"
                              : achievement.tier === "rare"
                                ? "bg-sky-500/20 text-sky-500"
                                : "bg-primary/20 text-primary"
                          : "bg-cell text-muted-foreground"
                      }`}
                    >
                      {isUnlocked ? (
                        achievement.tier === "legendary" ? (
                          <Sparkles className="size-6 text-amber-500 animate-pulse" />
                        ) : (
                          <Trophy className="size-6" />
                        )
                      ) : (
                        <Lock className="size-5" />
                      )}
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="truncate font-semibold tracking-tight text-foreground">
                          {achievement.name}
                        </h3>
                        <span className="shrink-0 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
                          +{achievement.reward_xp} XP
                        </span>
                      </div>

                      <div className="mt-1 flex items-center gap-1.5">
                        <span
                          className={`inline-flex items-center rounded-md border px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                            tierBadgeStyle[achievement.tier] ?? tierBadgeStyle["common"]
                          }`}
                        >
                          {achievement.tier}
                        </span>
                        <span className="text-[10px] font-medium capitalize text-muted-foreground">
                          · {achievement.category.replace("_", " ")}
                        </span>
                      </div>

                      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                        {achievement.description}
                      </p>
                    </div>
                  </div>

                  {/* Progress bar for locked achievements */}
                  {!isUnlocked && (
                    <div className="mt-3.5 space-y-1.5 rounded-2xl bg-cell/50 p-2.5">
                      <div className="flex items-center justify-between text-xs font-medium">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-mono text-foreground">{progress.label}</span>
                      </div>
                      <Progress value={progress.percentage} className="h-2" />
                    </div>
                  )}
                </div>

                {/* Footer status / actions */}
                <div className="mt-3.5 flex items-center justify-between border-t pt-2.5 text-xs">
                  {isUnlocked ? (
                    <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
                      <Check className="size-3.5" />
                      <span>
                        Unlocked {unlockedAt ? new Date(unlockedAt).toLocaleDateString() : ""}
                      </span>
                    </div>
                  ) : (
                    <span className="text-muted-foreground flex items-center gap-1 font-medium">
                      <Zap className="size-3 text-muted-foreground" />
                      In progress ({progress.percentage}%)
                    </span>
                  )}

                  {isUnlocked && (
                    <button
                      type="button"
                      aria-pressed={Boolean(unlock?.featured)}
                      disabled={
                        setFeatured.isPending ||
                        (!unlock?.featured &&
                          (data?.unlocked.filter((item) => item.is_featured).length ?? 0) >= 3)
                      }
                      onClick={() =>
                        setFeatured.mutate({
                          achievement_key: achievement.key,
                          featured: !unlock?.featured,
                        })
                      }
                      className="font-medium text-primary hover:underline disabled:opacity-50"
                    >
                      {unlock?.featured ? "Remove from showcase" : "Showcase"}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
