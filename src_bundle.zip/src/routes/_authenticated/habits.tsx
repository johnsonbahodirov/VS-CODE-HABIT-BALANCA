import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Minus, Plus } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const PICKER_COLORS = [
  "red",
  "orange",
  "amber",
  "lime",
  "green",
  "teal",
  "sky",
  "blue",
  "violet",
  "pink",
] as const;
const STEP =
  "flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-all hover:bg-primary/20 active:scale-90 disabled:opacity-40";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { HabitList } from "@/components/app-widgets";
import { colorBg, useAddHabit } from "@/lib/data";
import { cn } from "@/lib/utils";
import { HABIT_CATEGORIES, HABIT_ICONS } from "@/lib/habit-meta";

export const Route = createFileRoute("/_authenticated/habits")({
  head: () => ({ meta: [{ title: "Habits — Balance" }] }),
  component: Habits,
});

function Habits() {
  const [name, setName] = useState("");
  const [color, setColor] = useState<string>("rose");
  const [category, setCategory] = useState<string>("Health");
  const [icon, setIcon] = useState<string>("sparkles");
  const [dailyGoal, setDailyGoal] = useState(0);
  const [trackingType, setTrackingType] = useState<"yes_no" | "count">("yes_no");
  const [dailyGoalCount, setDailyGoalCount] = useState(1);
  const [description, setDescription] = useState("");
  const [frequency, setFrequency] = useState<
    "daily" | "weekdays" | "weekends" | "selected_days" | "custom"
  >("daily");
  const [scheduleDays, setScheduleDays] = useState([0, 1, 2, 3, 4, 5, 6]);
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState("09:00");
  const add = useAddHabit();
  const SelectedIcon = HABIT_ICONS[icon] ?? HABIT_ICONS["sparkles"]!;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Habits</h1>

      <details className="rounded-3xl border bg-surface">
        <summary className="cursor-pointer px-4 py-3 text-sm font-semibold text-primary">
          <Plus className="mr-2 inline size-4" />
          Create a habit
          <span className="ml-2 font-normal text-muted-foreground">
            Choose its schedule, tracking, and optional focus goal
          </span>
        </summary>

        <div className="px-4 pb-4">
          <form
            className="space-y-4"
            onSubmit={(event) => {
              event.preventDefault();
              if (!name.trim()) return;
              add.mutate(
                {
                  name: name.trim(),
                  color,
                  category,
                  icon,
                  daily_goal_minutes: dailyGoal,
                  tracking_type: trackingType,
                  daily_goal_count: dailyGoalCount,
                  description,
                  frequency: frequency === "weekends" ? "selected_days" : frequency,
                  schedule_days: scheduleDays,
                  difficulty,
                  reminder_enabled: reminderEnabled,
                  reminder_time: reminderTime,
                },
                {
                  onSuccess: () => {
                    setName("");
                    setDescription("");
                  },
                },
              );
            }}
          >
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="New habit, e.g. Read 20 pages"
              className="h-11 rounded-xl bg-cell"
            />

            <Textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Purpose or a short note (optional)"
              maxLength={1000}
              className="min-h-20 rounded-xl bg-cell"
            />

            <div className="grid grid-cols-2 gap-2">
              <div className="text-xs text-muted-foreground">
                Category
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="mt-1 h-10 w-full rounded-xl border-border/70 bg-cell text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {HABIT_CATEGORIES.map((item) => (
                      <SelectItem key={item} value={item}>
                        {item}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="text-xs text-muted-foreground">
                Daily focus goal (min, optional)
                <div className="mt-1 flex h-10 items-center justify-between rounded-xl border border-border/70 bg-cell px-1">
                  <button
                    type="button"
                    aria-label="Decrease focus minutes"
                    onClick={() => setDailyGoal((value) => Math.max(0, value - 5))}
                    disabled={dailyGoal <= 0}
                    className={STEP}
                  >
                    <Minus className="size-4" />
                  </button>
                  <span className="font-mono text-sm font-semibold text-foreground">
                    {dailyGoal > 0 ? `${dailyGoal}m` : "Not set"}
                  </span>
                  <button
                    type="button"
                    aria-label="Increase focus minutes"
                    onClick={() => setDailyGoal((value) => Math.min(600, value + 5))}
                    className={STEP}
                  >
                    <Plus className="size-4" />
                  </button>
                </div>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="text-xs text-muted-foreground">
                Frequency
                <Select
                  value={frequency}
                  onValueChange={(next) => {
                    setFrequency(next as typeof frequency);
                    if (next === "daily") setScheduleDays([0, 1, 2, 3, 4, 5, 6]);
                    if (next === "weekdays") setScheduleDays([1, 2, 3, 4, 5]);
                    if (next === "weekends") setScheduleDays([0, 6]);
                  }}
                >
                  <SelectTrigger className="mt-1 h-10 w-full rounded-xl border-border/70 bg-cell text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectItem value="daily">Every day</SelectItem>
                    <SelectItem value="weekdays">Weekdays</SelectItem>
                    <SelectItem value="weekends">Weekends</SelectItem>
                    <SelectItem value="selected_days">Specific days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="text-xs text-muted-foreground">
                Difficulty (optional)
                <Select
                  value={difficulty}
                  onValueChange={(value) => setDifficulty(value as typeof difficulty)}
                >
                  <SelectTrigger className="mt-1 h-10 w-full rounded-xl border-border/70 bg-cell text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {(frequency === "selected_days" || frequency === "custom") && (
              <div className="flex flex-wrap gap-2" role="group" aria-label="Scheduled weekdays">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day, index) => (
                  <button
                    type="button"
                    key={day}
                    aria-pressed={scheduleDays.includes(index)}
                    onClick={() =>
                      setScheduleDays((current) =>
                        current.includes(index)
                          ? current.filter((value) => value !== index)
                          : [...current, index].sort(),
                      )
                    }
                    className={cn(
                      "rounded-full px-3 py-1.5 text-xs font-medium",
                      scheduleDays.includes(index)
                        ? "bg-primary text-primary-foreground"
                        : "bg-cell text-muted-foreground",
                    )}
                  >
                    {day}
                  </button>
                ))}
              </div>
            )}

            {scheduleDays.length === 0 &&
              (frequency === "selected_days" || frequency === "custom") && (
                <p role="alert" className="text-xs text-destructive">
                  Choose at least one day for this schedule.
                </p>
              )}

            <fieldset className="space-y-3">
              <legend className="text-xs font-medium text-muted-foreground">Tracking</legend>
              <div className="grid grid-cols-2 rounded-2xl bg-cell p-1">
                {(
                  [
                    ["yes_no", "Yes / No"],
                    ["count", "Count"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    type="button"
                    key={value}
                    aria-pressed={trackingType === value}
                    onClick={() => setTrackingType(value)}
                    className={cn(
                      "rounded-xl py-2 text-sm font-semibold transition-colors",
                      trackingType === value
                        ? "bg-background text-foreground shadow-sm"
                        : "text-muted-foreground",
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>

              {trackingType === "count" && (
                <label className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
                  <span>
                    Daily count goal
                    <span className="mt-1 block text-[11px]">
                      Reaching this amount completes the day.
                    </span>
                  </span>
                  <span className="flex items-center gap-2">
                    <button
                      type="button"
                      aria-label="Decrease daily count goal"
                      disabled={dailyGoalCount <= 1}
                      onClick={() => setDailyGoalCount((value) => Math.max(1, value - 1))}
                      className={STEP}
                    >
                      <Minus className="size-4" />
                    </button>
                    <Input
                      type="number"
                      min={1}
                      max={999}
                      value={dailyGoalCount}
                      aria-label="Daily count goal"
                      onChange={(event) =>
                        setDailyGoalCount(
                          Math.max(1, Math.min(999, Number(event.target.value) || 1)),
                        )
                      }
                      className="h-10 w-16 rounded-xl bg-cell text-center font-mono"
                    />
                    <button
                      type="button"
                      aria-label="Increase daily count goal"
                      disabled={dailyGoalCount >= 999}
                      onClick={() => setDailyGoalCount((value) => Math.min(999, value + 1))}
                      className={STEP}
                    >
                      <Plus className="size-4" />
                    </button>
                  </span>
                </label>
              )}
            </fieldset>

            <div className="flex flex-wrap items-center gap-3 rounded-xl bg-cell/60 p-3">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(event) => setReminderEnabled(event.target.checked)}
                />
                Habit reminder
              </label>
              {reminderEnabled && (
                <Input
                  type="time"
                  aria-label="Habit reminder time"
                  value={reminderTime}
                  onChange={(event) => setReminderTime(event.target.value)}
                  className="w-32"
                />
              )}
            </div>

            {reminderEnabled && (
              <p className="-mt-2 text-[11px] text-muted-foreground">
                Push delivery requires notifications enabled in Profile and a scheduled reminder
                sender.
              </p>
            )}

            <div className="rounded-2xl border border-border/70 bg-gradient-to-br from-primary/10 via-cell/60 to-accent/10 p-3">
              <div className="relative flex items-center gap-3">
                <span
                  className={cn(
                    "flex size-12 items-center justify-center rounded-2xl text-background",
                    colorBg[color],
                  )}
                >
                  <SelectedIcon className="size-6" />
                </span>
                <p className="text-xs font-medium text-muted-foreground">Choose an icon</p>
              </div>

              <div className="relative mt-3 flex flex-wrap gap-2">
                {Object.entries(HABIT_ICONS)
                  .slice(0, 14)
                  .map(([iconName, Icon]) => (
                    <button
                      type="button"
                      key={iconName}
                      aria-label={`Choose ${iconName} icon`}
                      aria-pressed={icon === iconName}
                      title={iconName}
                      onClick={() => setIcon(iconName)}
                      className={cn(
                        "flex size-10 items-center justify-center rounded-2xl border transition-all duration-200 hover:-translate-y-0.5 active:scale-90",
                        icon === iconName
                          ? "scale-110 border-primary bg-primary text-primary-foreground shadow-md"
                          : "border-border/60 bg-surface text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <Icon className="size-4" />
                    </button>
                  ))}
              </div>
            </div>

            <fieldset>
              <legend className="mb-2 text-xs font-medium text-muted-foreground">Color</legend>
              <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
                {PICKER_COLORS.map((item) => (
                  <button
                    type="button"
                    key={item}
                    aria-label={item}
                    aria-pressed={color === item}
                    title={item}
                    onClick={() => setColor(item)}
                    className={cn(
                      "size-8 cursor-pointer rounded-xl transition-transform hover:scale-110 active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                      colorBg[item],
                      color === item && "ring-2 ring-foreground",
                    )}
                  >
                    {color === item && <Check className="m-auto size-4 text-background" />}
                  </button>
                ))}
              </div>
            </fieldset>

            <div className="flex justify-end">
              <Button
                type="submit"
                variant="neon"
                disabled={
                  add.isPending ||
                  ((frequency === "selected_days" || frequency === "custom") &&
                    scheduleDays.length === 0)
                }
              >
                <Plus /> Add
              </Button>
            </div>
          </form>
        </div>
      </details>

      <HabitList />
    </div>
  );
}
