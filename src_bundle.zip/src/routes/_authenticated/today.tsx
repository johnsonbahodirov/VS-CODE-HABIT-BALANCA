import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Clock3, Flame, Plus, Sparkles, Target, Trophy } from "lucide-react";
import { HabitList, SessionList, TimerCard } from "@/components/app-widgets";
import { XpProgressCard } from "@/components/progress-widgets";
import { DatabaseErrorNotice } from "@/components/database-error-notice";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { dayKey, formatMinutes, minutesByDay } from "@/lib/balance";
import {
  useAchievements,
  useAddHabit,
  useHabitLogs,
  useHabits,
  useSessions,
  useSettings,
} from "@/lib/data";
import { detectComeback, isHabitScheduledOnDay, scheduledStreakStats } from "@/lib/gamification";

export const Route = createFileRoute("/_authenticated/today")({
  head: () => ({ meta: [{ title: "Today — Balance" }] }),
  component: Today,
});

function useCurrentTime(): Date {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(timer);
  }, []);

  return now;
}

function Today() {
  const now = useCurrentTime();
  const date = now.toLocaleDateString([], {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  const sessionsQuery = useSessions();
  const settingsQuery = useSettings();
  const habitsQuery = useHabits();
  const logsQuery = useHabitLogs();
  const achievementsQuery = useAchievements();
  const addHabit = useAddHabit();

  const [quickHabit, setQuickHabit] = useState("");
  const [dismissedComeback, setDismissedComeback] = useState(false);

  const todayKeyStr = dayKey(now);
  const sessions = sessionsQuery.data ?? [];
  const habits = habitsQuery.data ?? [];
  const logs = useMemo(() => logsQuery.data ?? [], [logsQuery.data]);

  const unlocked = new Set(
    (achievementsQuery.data?.unlocked ?? []).map((item) => item.achievement_key),
  );
  const nextAchievement = achievementsQuery.data?.catalog.find(
    (item) => !unlocked.has(item.key),
  );

  const timeByDay = minutesByDay(sessions, now);
  const todayMinutes = timeByDay.get(todayKeyStr) ?? 0;

  const pomodorosToday = sessions.filter((session) => {
    if (session.mode !== "pomodoro" || !session.ended_at) return false;
    return dayKey(new Date(session.started_at)) === todayKeyStr;
  }).length;

  const isNewUser = !habitsQuery.isLoading && !habitsQuery.isError && habits.length === 0;

  const comebackData = useMemo(() => {
    if (isNewUser || logs.length === 0) return null;

    const completedDays = logs.map((log) => log.day);
    const info = detectComeback(completedDays, todayKeyStr, 7);

    let effectiveInactiveDays = info.daysInactive;
    if (typeof window !== "undefined") {
      const lastVisit = localStorage.getItem("balance_last_visit_date");
      if (lastVisit && lastVisit !== todayKeyStr) {
        const diff = Math.round(
          (new Date(`${todayKeyStr}T12:00:00`).getTime() -
            new Date(`${lastVisit}T12:00:00`).getTime()) /
            86400000,
        );
        if (diff > effectiveInactiveDays) effectiveInactiveDays = diff;
      }
    }

    return {
      isComeback: effectiveInactiveDays >= 7,
      daysInactive: effectiveInactiveDays,
    };
  }, [isNewUser, logs, todayKeyStr]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const ack = localStorage.getItem(`balance_comeback_ack_${todayKeyStr}`);
    if (ack) setDismissedComeback(true);
    localStorage.setItem("balance_last_visit_date", todayKeyStr);
  }, [todayKeyStr]);

  const scheduledHabits = habits.filter(
    (habit) =>
      !habit.is_paused &&
      !habit.archived_at &&
      isHabitScheduledOnDay(habit, todayKeyStr),
  );

  const dailyGoal = scheduledHabits.reduce(
    (sum, habit) => sum + Math.max(0, habit.daily_goal_minutes ?? 0),
    0,
  );

  const completedHabitIds = new Set(
    logs
      .filter((log) => {
        const habit = habits.find((item) => item.id === log.habit_id);
        if (!habit || log.day !== todayKeyStr) return false;

        return habit.tracking_type === "count"
          ? (log.count ?? 0) >= (habit.daily_goal_count ?? 1)
          : (log.count ?? 1) >= 1;
      })
      .map((log) => log.habit_id),
  );

  const completedToday = scheduledHabits.filter((habit) =>
    completedHabitIds.has(habit.id),
  ).length;

  const completionRate = scheduledHabits.length
    ? Math.round((completedToday / scheduledHabits.length) * 100)
    : 0;

  const currentStreak = Math.max(
    0,
    ...habits
      .filter((habit) => !habit.archived_at && !habit.is_paused)
      .map((habit) => {
        const completedDays = logs
          .filter((log) => {
            if (log.habit_id !== habit.id) return false;

            return habit.tracking_type === "count"
              ? (log.count ?? 0) >= (habit.daily_goal_count ?? 1)
              : (log.count ?? 1) >= 1;
          })
          .map((log) => log.day);

        return scheduledStreakStats(completedDays, todayKeyStr, habit).current;
      }),
  );

  const starters = [
    { name: "Drink water", icon: "droplets", category: "Health" },
    { name: "Read 20 minutes", icon: "book", category: "Learning" },
    { name: "Walk 30 minutes", icon: "footprints", category: "Health" },
  ];

  const addStarter = (starter: { name: string; icon: string; category: string }) =>
    addHabit.mutate({
      name: starter.name,
      color: "green",
      category: starter.category,
      icon: starter.icon,
      description: "",
      frequency: "daily",
      schedule_days: [0, 1, 2, 3, 4, 5, 6],
      difficulty: "medium",
      reminder_enabled: false,
      reminder_time: "09:00",
      tracking_type: "yes_no",
      daily_goal_count: 1,
      daily_goal_minutes: 0,
    });

  const addQuickHabit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const name = quickHabit.trim();
    if (!name) return;

    addHabit.mutate(
      {
        name,
        color: "green",
        category: "Health",
        icon: "sparkles",
        description: "",
        frequency: "daily",
        schedule_days: [0, 1, 2, 3, 4, 5, 6],
        difficulty: "medium",
        reminder_enabled: false,
        reminder_time: "09:00",
        tracking_type: "yes_no",
        daily_goal_count: 1,
        daily_goal_minutes: 0,
      },
      {
        onSuccess: () => setQuickHabit(""),
      },
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-sm text-muted-foreground">{date}</p>
          <h1 className="text-3xl font-bold">Today</h1>
        </div>
        <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          Your daily reset
        </span>
      </div>

      {(sessionsQuery.isError ||
        settingsQuery.isError ||
        habitsQuery.isError ||
        logsQuery.isError ||
        achievementsQuery.isError) && (
        <DatabaseErrorNotice
          title="Today’s progress could not be fully loaded"
          error={
            sessionsQuery.error ??
            settingsQuery.error ??
            habitsQuery.error ??
            logsQuery.error ??
            achievementsQuery.error
          }
          onRetry={() => {
            void Promise.all([
              sessionsQuery.refetch(),
              settingsQuery.refetch(),
              habitsQuery.refetch(),
              logsQuery.refetch(),
              achievementsQuery.refetch(),
            ]);
          }}
        />
      )}

      {comebackData?.isComeback && !dismissedComeback && (
        <section className="relative overflow-hidden rounded-3xl border border-accent/40 bg-gradient-to-br from-accent/20 via-surface to-primary/10 p-5 shadow-sm">
          <div className="flex items-start gap-4">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-accent text-accent-foreground shadow-md shadow-accent/20">
              <Sparkles className="size-6" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg font-bold tracking-tight text-foreground">
                  Welcome back! 🌟
                </h2>
                <span className="rounded-full bg-accent/20 px-2.5 py-0.5 text-xs font-semibold text-accent">
                  {comebackData.daysInactive} days away
                </span>
              </div>
              <p className="mt-1 text-sm leading-relaxed text-foreground/85">
                Taking a break is completely normal and part of being human. True consistency isn&apos;t
                about never pausing—it&apos;s about having the strength to return. Let&apos;s make today
                count!
              </p>
              <div className="mt-3.5 flex flex-wrap items-center gap-3">
                <Button
                  size="sm"
                  className="rounded-full bg-accent font-semibold text-accent-foreground hover:bg-accent/90"
                  onClick={() => {
                    setDismissedComeback(true);
                    localStorage.setItem(`balance_comeback_ack_${todayKeyStr}`, "true");
                  }}
                >
                  Let&apos;s do this! ✨
                </Button>
                <button
                  type="button"
                  onClick={() => {
                    setDismissedComeback(true);
                    localStorage.setItem(`balance_comeback_ack_${todayKeyStr}`, "true");
                  }}
                  className="text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {isNewUser ? (
        <section className="space-y-3 rounded-3xl border bg-gradient-to-br from-primary/10 via-surface to-surface p-5">
          <h2 className="text-lg font-semibold">Welcome to Balance</h2>
          <ol className="list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
            <li>Add one small habit you can finish every day.</li>
            <li>Tap the check when it is done and earn XP.</li>
            <li>Use the timer to track how long you focus on it.</li>
          </ol>
          <p className="pt-1 text-xs font-semibold text-muted-foreground">Start with one tap:</p>
          <div className="flex flex-wrap gap-2">
            {starters.map((starter) => (
              <Button
                key={starter.name}
                type="button"
                size="sm"
                variant="outline"
                disabled={addHabit.isPending}
                onClick={() => addStarter(starter)}
              >
                <Plus /> {starter.name}
              </Button>
            ))}
          </div>
        </section>
      ) : (
        <section className="rounded-3xl border bg-gradient-to-br from-primary/10 via-surface to-surface p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Target className="size-4 text-primary" /> Today’s progress
              </div>
              <p className="mt-1 font-mono text-4xl font-bold">
                {completedToday}/{scheduledHabits.length}
              </p>
              <p className="text-sm text-muted-foreground">{completionRate}% of habits done</p>
            </div>
            <div className="text-right">
              <div className="flex items-center justify-end gap-2 text-xs text-muted-foreground">
                <Flame className="size-4 text-accent" /> Current streak
              </div>
              <p className="mt-1 font-mono text-3xl font-bold">
                {currentStreak}{" "}
                <span className="text-sm font-medium text-muted-foreground">days</span>
              </p>
            </div>
          </div>
          <Progress value={completionRate} className="mt-4 h-2" />
        </section>
      )}

      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-lg font-semibold">Habits</h2>
          <Link
            to="/habits"
            viewTransition
            preload="intent"
            preloadDelay={0}
            className="text-sm text-primary"
          >
            Manage
          </Link>
        </div>

        <HabitList showGrid={false} />

        {!isNewUser && (
          <form
            className="mt-3 flex items-center gap-2 rounded-2xl border bg-surface px-2 py-2"
            onSubmit={addQuickHabit}
          >
            <Input
              value={quickHabit}
              onChange={(event) => setQuickHabit(event.target.value)}
              placeholder="Add a habit"
              aria-label="Quick add a habit"
              maxLength={120}
              className="h-9 min-w-0 border-0 bg-transparent shadow-none focus-visible:ring-0"
            />
            <Button
              type="submit"
              size="sm"
              variant="outline"
              aria-label="Add habit"
              disabled={!quickHabit.trim() || addHabit.isPending}
              className="size-9 shrink-0 px-0"
            >
              <Plus className="size-4" />
            </Button>
          </form>
        )}
      </section>

      <div className="flex items-center justify-between rounded-2xl border bg-surface px-4 py-2.5">
        <span className="flex items-center gap-2 text-xs text-muted-foreground">
          <span aria-hidden="true">🍅</span>
          Pomodoro sessions today
        </span>
        <span className="font-mono text-sm font-semibold">{pomodorosToday}</span>
      </div>

      <TimerCard />

      {dailyGoal > 0 && (
        <section className="flex items-center gap-3 rounded-2xl border bg-surface px-4 py-2.5">
          <Clock3 className="size-4 shrink-0 text-primary" />
          <span className="text-xs text-muted-foreground">Today’s plan</span>
          <Progress
            value={Math.min(100, (todayMinutes / dailyGoal) * 100)}
            className="h-2 flex-1"
          />
          <span className="font-mono text-xs font-semibold">
            {formatMinutes(todayMinutes)} / {formatMinutes(dailyGoal)}
          </span>
        </section>
      )}

      {nextAchievement && (
        <section className="flex items-center gap-4 rounded-3xl border border-accent/30 bg-gradient-to-br from-accent/15 via-surface to-primary/5 p-4">
          <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-accent text-accent-foreground shadow-sm">
            <Trophy className="size-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-muted-foreground">Next achievement</p>
            <p className="truncate text-sm font-semibold">{nextAchievement.name}</p>
          </div>
          <span className="shrink-0 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
            +{nextAchievement.reward_xp} XP
          </span>
        </section>
      )}

      <XpProgressCard compact />

      <details className="rounded-2xl border bg-surface px-4 py-3">
        <summary className="cursor-pointer text-sm font-semibold">Recent focus sessions</summary>
        <div className="mt-3">
          <SessionList />
        </div>
      </details>
    </div>
  );
}
