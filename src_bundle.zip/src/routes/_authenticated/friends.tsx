import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, UserPlus, Users, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { DatabaseErrorNotice } from "@/components/database-error-notice";
import { Input } from "@/components/ui/input";
import {
  useBlockFriend,
  useRemoveFriend,
  useRespondFriendRequest,
  useSendFriendRequest,
  useSocialOverview,
  useUnblockFriend,
  useUpdateSocialSettings,
} from "@/lib/data";
import type { SocialOverview } from "@/lib/social-types";
import { normalizeFriendCode } from "@/lib/social";

export const Route = createFileRoute("/_authenticated/friends")({
  head: () => ({ meta: [{ title: "Friends — Balance" }] }),
  component: Friends,
});

function Friends() {
  const overview = useSocialOverview();
  const saveSettings = useUpdateSocialSettings();
  const sendRequest = useSendFriendRequest();
  const respondRequest = useRespondFriendRequest();
  const removeFriend = useRemoveFriend();
  const blockFriend = useBlockFriend();
  const unblockFriend = useUnblockFriend();
  const initialized = useRef(false);
  const [displayName, setDisplayName] = useState("");
  const [shareProgress, setShareProgress] = useState(false);
  const [sharePresence, setSharePresence] = useState(false);
  const [friendCode, setFriendCode] = useState("");

  useEffect(() => {
    if (!overview.data || initialized.current) return;
    initialized.current = true;
    setDisplayName(overview.data.profile.display_name);
    setShareProgress(overview.data.profile.share_progress);
    setSharePresence(overview.data.profile.share_presence);
  }, [overview.data]);

  const saveProfile = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await saveSettings.mutateAsync({ displayName, shareProgress, sharePresence });
      toast.success("Friend profile saved");
    } catch {
      // Mutation reports the backend error.
    }
  };

  const addFriend = async (event: React.FormEvent) => {
    event.preventDefault();
    const code = normalizeFriendCode(friendCode);
    if (!code) {
      toast.error("Enter a 6-digit friend ID.");
      return;
    }
    try {
      const result = await sendRequest.mutateAsync(code);
      const messages: Record<string, { title: string; description?: string }> = {
        sent: { title: "Friend request sent" },
        accepted: { title: "You're now friends" },
        already_friends: { title: "Already friends" },
        request_pending: { title: "Request already sent" },
        blocked: { title: "This account can't receive a friend request." },
        not_found: { title: "No account has that friend ID." },
        invalid_code: { title: "Enter a valid 6-digit friend ID." },
        self: { title: "You can't add your own ID." },
        rate_limited: {
          title: "Too many attempts",
          description: "Please wait before trying another friend ID.",
        },
      };
      const message = messages[result] ?? { title: "Friend request could not be sent." };
      if (result === "sent" || result === "accepted") {
        toast.success(message.title);
        setFriendCode("");
      } else {
        toast.error(message.title, { description: message.description });
      }
    } catch {
      // Mutation reports the backend error.
    }
  };

  const copyCode = async () => {
    const code = overview.data?.profile.friend_code;
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      toast.success("Friend ID copied");
    } catch {
      toast.error("Could not copy the friend ID. Select and copy it manually.");
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm text-muted-foreground">Study together, at your own pace</p>
        <h1 className="text-3xl font-bold">Friends</h1>
      </header>

      {overview.isError ? (
        <DatabaseErrorNotice
          title="Friends are not ready yet"
          error={overview.error}
          onRetry={() => {
            void overview.refetch();
          }}
        />
      ) : overview.isLoading || !overview.data ? (
        <div className="h-40 animate-pulse rounded-3xl bg-cell" />
      ) : (
        <>
          <section className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-surface px-4 py-3">
            <div className="flex min-w-0 items-center gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Your friend ID</p>
                <p className="font-mono text-xl font-bold tracking-[0.16em]">
                  {overview.data.profile.friend_code}
                </p>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={copyCode}>
                <Copy /> Copy
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Share this ID with people you know.
            </p>
          </section>

          <form onSubmit={addFriend} className="rounded-3xl border bg-surface p-5">
            <div className="mb-3 flex items-center gap-2">
              <UserPlus className="size-5 text-primary" />
              <h2 className="font-semibold">Add a friend</h2>
            </div>
            <div className="flex gap-2">
              <Input
                aria-label="Friend ID"
                inputMode="numeric"
                autoComplete="off"
                maxLength={6}
                pattern="[0-9]{6}"
                placeholder="6-digit friend ID"
                value={friendCode}
                onChange={(event) =>
                  setFriendCode(event.target.value.replace(/\D/g, "").slice(0, 6))
                }
              />
              <Button type="submit" disabled={friendCode.length !== 6 || sendRequest.isPending}>
                Send
              </Button>
            </div>
          </form>

          <details className="rounded-2xl border bg-surface">
            <summary className="cursor-pointer px-4 py-3 text-sm font-semibold">
              Sharing and privacy
              <span className="ml-2 font-normal text-muted-foreground">
                Choose what friends can see
              </span>
            </summary>
            <form onSubmit={saveProfile} className="space-y-4 border-t px-4 py-4">
              <p className="text-xs text-muted-foreground">
                Only accepted friends can see information you choose to share. Both options start
                off.
              </p>

              <label className="block">
                <span className="mb-1 block text-sm font-medium">Display name</span>
                <Input
                  maxLength={32}
                  required
                  value={displayName}
                  onChange={(event) => setDisplayName(event.target.value)}
                  placeholder="Name friends will see"
                />
              </label>

              <label className="flex items-start gap-3 rounded-2xl bg-cell/70 p-3">
                <input
                  type="checkbox"
                  checked={shareProgress}
                  onChange={(event) => setShareProgress(event.target.checked)}
                  className="mt-1 size-4 accent-primary"
                />
                <span>
                  <span className="block text-sm font-medium">Share XP and habit progress</span>
                  <span className="block text-xs text-muted-foreground">
                    Friends can see your level and up to 3 most-completed habits.
                  </span>
                </span>
              </label>

              <label className="flex items-start gap-3 rounded-2xl bg-cell/70 p-3">
                <input
                  type="checkbox"
                  checked={sharePresence}
                  onChange={(event) => setSharePresence(event.target.checked)}
                  className="mt-1 size-4 accent-primary"
                />
                <span>
                  <span className="block text-sm font-medium">Share online status and focus</span>
                  <span className="block text-xs text-muted-foreground">
                    Friends can see when you are online and the habit attached to your active timer.
                    Online status updates while the app is open.
                  </span>
                </span>
              </label>

              <Button type="submit" size="sm" disabled={saveSettings.isPending}>
                Save privacy settings
              </Button>
            </form>
          </details>

          {overview.data.incoming.length > 0 && (
            <section className="rounded-3xl border bg-surface p-5">
              <h2 className="mb-3 font-semibold">Friend requests</h2>
              <ul className="space-y-2">
                {overview.data.incoming.map((request) => (
                  <li
                    key={request.request_id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-cell/70 p-3"
                  >
                    <div>
                      <p className="font-medium">{request.display_name}</p>
                      <p className="font-mono text-xs text-muted-foreground">
                        ID {request.friend_code}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        disabled={respondRequest.isPending || blockFriend.isPending}
                        onClick={() =>
                          respondRequest.mutate({ requestId: request.request_id, accept: true })
                        }
                      >
                        <Check /> Accept
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={respondRequest.isPending || blockFriend.isPending}
                        aria-label={`Decline request from ${request.display_name}`}
                        onClick={() =>
                          respondRequest.mutate({ requestId: request.request_id, accept: false })
                        }
                      >
                        <X />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={blockFriend.isPending || respondRequest.isPending}
                        onClick={() => {
                          if (window.confirm(`Block ${request.display_name}?`)) {
                            blockFriend.mutate(request.friend_code);
                          }
                        }}
                      >
                        Block
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {overview.data.outgoing.length > 0 && (
            <section className="rounded-3xl border bg-surface p-5">
              <h2 className="mb-3 font-semibold">Sent requests</h2>
              <ul className="space-y-2">
                {overview.data.outgoing.map((request) => (
                  <li
                    key={request.friend_code}
                    className="flex items-center justify-between rounded-2xl bg-cell/70 p-3"
                  >
                    <span className="font-medium">{request.display_name}</span>
                    <span className="text-xs text-muted-foreground">Waiting for response</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {overview.data.blocked.length > 0 && (
            <section className="rounded-3xl border bg-surface p-5">
              <h2 className="mb-3 font-semibold">Blocked accounts</h2>
              <ul className="space-y-2">
                {overview.data.blocked.map((blocked) => (
                  <li
                    key={blocked.friend_code}
                    className="flex items-center justify-between rounded-2xl bg-cell/70 p-3"
                  >
                    <div>
                      <p className="font-medium">{blocked.display_name}</p>
                      <p className="font-mono text-xs text-muted-foreground">
                        ID {blocked.friend_code}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={unblockFriend.isPending}
                      onClick={() => unblockFriend.mutate(blocked.friend_code)}
                    >
                      Unblock
                    </Button>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section>
            <div className="mb-3 flex items-center gap-2">
              <Users className="size-5 text-primary" />
              <h2 className="text-lg font-semibold">Friend activity</h2>
            </div>
            {overview.data.friends.length === 0 ? (
              <p className="rounded-3xl border border-dashed p-5 text-center text-sm text-muted-foreground">
                Add friends to see their shared activity here.
              </p>
            ) : (
              <ul className="space-y-2">
                {overview.data.friends.map((friend) => (
                  <li
                    key={`activity-${friend.friend_code}`}
                    className="flex items-center justify-between gap-3 rounded-2xl border bg-surface px-4 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{friend.display_name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {!friend.share_presence
                          ? "Activity is private"
                          : friend.is_online
                            ? friend.current_habit
                              ? `Focusing on ${friend.current_habit}`
                              : "Online · no active timer"
                            : "Offline"}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-medium ${
                        friend.share_presence && friend.is_online
                          ? "bg-primary/10 text-primary"
                          : "bg-cell text-muted-foreground"
                      }`}
                    >
                      {!friend.share_presence
                        ? "Private"
                        : friend.is_online
                          ? "Active"
                          : "Offline"}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section>
            <div className="mb-3 flex items-center gap-2">
              <Users className="size-5 text-primary" />
              <h2 className="text-lg font-semibold">Your friends</h2>
              <span className="text-sm text-muted-foreground">
                ({overview.data.friends.length})
              </span>
            </div>
            {overview.data.friends.length === 0 ? (
              <p className="rounded-3xl border border-dashed p-6 text-center text-sm text-muted-foreground">
                No friends yet. Share your ID or add someone with theirs.
              </p>
            ) : (
              <ul className="space-y-3">
                {overview.data.friends.map((friend) => (
                  <FriendCard
                    key={friend.friend_code}
                    friend={friend}
                    removePending={removeFriend.isPending}
                    blockPending={blockFriend.isPending}
                    onRemove={() => {
                      if (window.confirm(`Remove ${friend.display_name} from your friends?`)) {
                        removeFriend.mutate(friend.friend_code);
                      }
                    }}
                    onBlock={() => {
                      if (
                        window.confirm(
                          `Block ${friend.display_name}? They will be removed as a friend.`,
                        )
                      ) {
                        blockFriend.mutate(friend.friend_code);
                      }
                    }}
                  />
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}

function FriendCard({
  friend,
  removePending,
  blockPending,
  onRemove,
  onBlock,
}: {
  friend: SocialOverview["friends"][number];
  removePending: boolean;
  blockPending: boolean;
  onRemove: () => void;
  onBlock: () => void;
}) {
  return (
    <li className="rounded-3xl border bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate font-semibold">{friend.display_name}</p>
          <p className="font-mono text-xs text-muted-foreground">ID {friend.friend_code}</p>
        </div>
        <div className="flex gap-2">
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={removePending}
            onClick={onRemove}
          >
            Remove
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={blockPending}
            onClick={onBlock}
          >
            Block
          </Button>
        </div>
      </div>

      <p className="mt-3 flex items-center gap-2 text-sm">
        <span
          aria-hidden="true"
          className={`size-2.5 rounded-full ${
            friend.share_presence
              ? friend.is_online
                ? "bg-primary"
                : "bg-muted-foreground"
              : "bg-cell"
          }`}
        />
        {friend.share_presence
          ? friend.is_online
            ? "Online"
            : "Offline"
          : "Online status private"}
      </p>

      {friend.share_presence && friend.is_online && (
        <p className="mt-1 text-sm text-muted-foreground">
          {friend.current_habit ? `Focusing on ${friend.current_habit}` : "No active timer"}
        </p>
      )}

      {friend.share_progress ? (
        <div className="mt-3 rounded-2xl bg-cell/70 p-3">
          <p className="text-sm font-semibold">
            Level {friend.level} · {(friend.total_xp ?? 0).toLocaleString()} XP
          </p>
          {friend.top_habits?.length ? (
            <div className="mt-2 flex flex-wrap gap-2">
              {friend.top_habits.map((habit) => (
                <span
                  key={habit.name}
                  className="rounded-full bg-surface px-2.5 py-1 text-xs text-muted-foreground"
                >
                  {habit.name} · {habit.completions}
                </span>
              ))}
            </div>
          ) : (
            <p className="mt-1 text-xs text-muted-foreground">No completed habits yet.</p>
          )}
        </div>
      ) : (
        <p className="mt-2 text-xs text-muted-foreground">Progress is private.</p>
      )}
    </li>
  );
}
