import {
  createFileRoute,
  redirect,
  Outlet,
  Link,
  useNavigate,
  useRouterState,
} from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  CalendarCheck,
  ChartNoAxesCombined,
  Trophy,
  UserRound,
  Sun,
  LogOut,
  Users,
} from "lucide-react";
import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { GamificationFeedback } from "@/components/progress-widgets";
import { DailyGoalSuggestionDialog } from "@/components/daily-goal-suggestion-dialog";
import { useSettings } from "@/lib/data";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    // Local session check: avoids a network call on every tab switch.
    const { data, error } = await supabase.auth.getSession();
    if (error && import.meta.env.DEV) {
      console.warn("[Supabase Auth] Protected route session check failed", {
        name: error.name,
        code: "code" in error ? error.code : undefined,
      });
    }
    const user = data.session?.user;
    if (!user) throw redirect({ to: "/auth" });
    return { user };
  },
  component: AppLayout,
});

const tabs = [
  { to: "/today", label: "Today", icon: Sun },
  { to: "/habits", label: "Habits", icon: CalendarCheck },
  { to: "/stats", label: "Stats", icon: ChartNoAxesCombined },
  { to: "/friends", label: "Friends", icon: Users },
  { to: "/achievements", label: "Rewards", icon: Trophy },
  { to: "/profile", label: "Profile", icon: UserRound },
] as const;

function AppLayout() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT") {
        void navigate({ to: "/auth", replace: true });
      }
    });
    return () => data.subscription.unsubscribe();
  }, [navigate]);
  // Loading settings also syncs the browser timezone to the server (XP and streak days).
  useSettings();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const supportsViewTransitions =
    typeof document !== "undefined" && "startViewTransition" in document;
  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.rpc("heartbeat_social_presence", { p_online: false });
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
  return (
    <div className="mx-auto min-h-screen max-w-3xl pb-28">
      <SocialPresenceHeartbeat />
      <GamificationFeedback />
      <DailyGoalSuggestionDialog />
      <header className="flex items-center justify-between px-5 pt-6">
        <span className="font-mono text-sm font-bold tracking-widest text-primary">BALANCE</span>
        <button
          onClick={signOut}
          aria-label="Sign out"
          className="rounded-full p-2 text-muted-foreground hover:bg-muted"
        >
          <LogOut className="size-4" />
        </button>
      </header>
      <main className="app-route-content px-5 pt-4">
        <div key={pathname} className={supportsViewTransitions ? undefined : "route-enter"}>
          <Outlet />
        </div>
      </main>
      <nav
        aria-label="Main navigation"
        className="fixed inset-x-0 bottom-[max(0.75rem,env(safe-area-inset-bottom))] z-20 mx-auto flex w-[min(96%,42rem)] justify-around rounded-3xl border bg-surface/95 p-1.5 shadow-lg backdrop-blur-md sm:p-2"
      >
        {tabs.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            viewTransition
            preload="intent"
            preloadDelay={0}
            className="flex flex-1 flex-col items-center justify-center gap-0.5 rounded-2xl px-1 py-1.5 text-[9px] font-medium text-muted-foreground transition-all select-none touch-manipulation active:scale-95 sm:py-2 sm:text-xs"
            activeProps={{ className: "bg-muted font-semibold text-primary shadow-xs" }}
          >
            <Icon className="size-4.5 shrink-0 sm:size-5" />
            <span className="truncate">{label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}

function SocialPresenceHeartbeat() {
  const loggedFailure = useRef(false);

  useEffect(() => {
    const heartbeat = () => {
      void supabase.rpc("heartbeat_social_presence").then(({ error }) => {
        if (error && !loggedFailure.current) {
          console.warn("Could not update friend presence; apply the friends migration.", error);
          loggedFailure.current = true;
        } else if (!error) {
          loggedFailure.current = false;
        }
      });
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") heartbeat();
    };
    heartbeat();
    const interval = window.setInterval(heartbeat, 60_000);
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, []);

  return null;
}
